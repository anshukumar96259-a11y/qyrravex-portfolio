const SYSTEM_PROMPT = `You are Qyrravex, the personal AI assistant on Anshu's portfolio website. Be helpful, clear, honest, and concise. The owner is a creative learner interested in AI tools, video editing, content creation, and web projects. Do not claim to be a separately trained foundation model. You are an AI assistant powered by the model configured by the site's owner. If asked about Anshu, only use details visible on the portfolio and do not invent credentials, clients, or achievements.`;
export async function onRequestPost({ request, env }) {
  if (!env.GEMINI_API_KEY) {
    return Response.json({ error: "Server setup incomplete: add GEMINI_API_KEY in the hosting provider's server-side environment variables." }, { status: 503 });
  }
  let body;
  try { body = await request.json(); } catch { return Response.json({ error: "Send a valid JSON message." }, { status: 400 }); }
  const incoming = Array.isArray(body.messages) ? body.messages.slice(-12) : [];
  const contents = incoming
    .filter(m => (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
    .map(m => ({ role: m.role === "assistant" ? "model" : "user", parts: [{ text: m.content.slice(0, 4000) }] }));
  if (!contents.length || contents[contents.length - 1].role !== "user") {
    return Response.json({ error: "Please send a message first." }, { status: 400 });
  }
  try {
    const response = await fetch("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": env.GEMINI_API_KEY },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] },
        contents,
        generationConfig: { temperature: 0.7, maxOutputTokens: 700 }
      })
    });
    const data = await response.json();
    if (!response.ok) {
      return Response.json({ error: response.status === 429 ? "The free model limit may have been reached. Try again later." : "The AI provider returned an error. Check the API key and model access." }, { status: response.status === 429 ? 429 : 502 });
    }
    const reply = data.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("").trim();
    if (!reply) return Response.json({ error: "The model returned no text. Please try again." }, { status: 502 });
    return Response.json({ reply }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return Response.json({ error: "Couldn't reach the AI provider. Check the deployment and try again." }, { status: 502 });
  }
}
